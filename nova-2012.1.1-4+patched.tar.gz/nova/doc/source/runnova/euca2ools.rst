Euca2ools
=========

Nova is compatible with most of the euca2ools command line utilities.  Both Administrators and Users will find these tools helpful for day-to-day administration.

* euca-add-group
* euca-delete-bundle
* euca-describe-instances
* euca-register
* euca-add-keypair
* euca-delete-group
* euca-describe-keypairs
* euca-release-address
* euca-allocate-address
* euca-delete-keypair
* euca-describe-regions
* euca-reset-image-attribute
* euca-associate-address
* euca-delete-snapshot
* euca-describe-snapshots
* euca-revoke
* euca-attach-volume
* euca-delete-volume
* euca-describe-volumes
* euca-run-instances
* euca-authorize
* euca-deregister
* euca-detach-volume
* euca-terminate-instances
* euca-bundle-image
* euca-describe-addresses
* euca-disassociate-address
* euca-unbundle
* euca-bundle-vol
* euca-describe-availability-zones
* euca-download-bundle
* euca-upload-bundle
* euca-confirm-product-instance
* euca-describe-groups
* euca-get-console-output
* euca-version
* euca-create-snapshot
* euca-describe-image-attribute
* euca-modify-image-attribute
* euca-create-volume
* euca-describe-images
* euca-reboot-instances


